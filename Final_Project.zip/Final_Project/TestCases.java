package Final_Project;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class TestCases {
	public class TestCasesAll {
		 WebDriver driver=null;

		 @BeforeMethod ()
		 public void OpenBrowser()// 1st case
		 {

		 System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		 WebDriver driver=new ChromeDriver();
		 driver.get("https://www.qa.jbktest.com/online-exam#Testing");
		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 }
	} 
	public void CheckSignupFunctionality() //2 nd case

	{
	WebDriver driver = null;
	Actions actions = new Actions(driver);
	driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();
	driver.findElement(By.id("countbtn")).click();
	driver.findElement(By.id("loginmobile")).sendKeys("9067250618");
	driver.findElement(By.id("loginbtn")).click();
	driver.findElement(By.id("signup-tab")).click();
	driver.findElement(By.id("name")).sendKeys("Pooja");
	driver.findElement(By.id("emailid")).sendKeys("poojapawar9067@gmail.com");

	driver.findElement(By.id("mobile")).sendKeys("9067250618");
	driver.findElement(By.id("agree")).click();
	actions.sendKeys(Keys.ARROW_DOWN).perform();
	driver.findElement(By.id("emailbtn")).click();
	String ActualResult = driver.findElement(By.xpath("//*[text()='Mobile number already exists, please login with this mobile number']")).getText();
	String AxpecteddResult="Mobile number already exists, please login with this mobile number";
	//driver.close();
	Assert.assertEquals(ActualResult, AxpecteddResult);

	}
	public void CheckExam20QueFunctionality()

	 {
		WebDriver driver = null;
		Actions actions = new Actions(driver);
	driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
	 driver.findElement(By.xpath("//*[@id='quizcount']/div[1]/input[2]")).click();
	 String val =
	driver.findElement(By.xpath("//*[@id='quizcount']/div[1]/input[2]")).getAttribute("value");
	 System.out.println(" Attempted Questions --> " +val);
	 driver.findElement(By.id("countbtn")).click();
	 driver.findElement(By.id("loginmobile")).sendKeys("9067250618");
	 driver.findElement(By.id("loginbtn")).click();
	 int num=Integer.parseInt(val);
	 for(int i=0;i<=num+2;i++)

	 {
	 WebElement nextButton =driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
	 JavascriptExecutor js = (JavascriptExecutor)driver;
	 js.executeScript("arguments[0].click()", nextButton);
	 driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");

	 }
	 driver.findElement(By.id("qsubmit")).click();

	 String msg =driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
	 System.out.println(msg);

	 String expectedResulte="Your Result";
	 String actualResult=driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
	 //driver.close();
	 Assert.assertEquals(actualResult, expectedResulte);

	 }
	 public void CheckExam25QueFunctionality()

	 {
	  WebDriver driver = null;
	 Actions actions = new Actions(driver);
	 driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
	 driver.findElement(By.xpath("//*[@id='quizcount']/div[1]/input[3]")).click();
	 String val =
	driver.findElement(By.xpath("//*[@id='quizcount']/div[1]/input[3]")).getAttribute("value");
	 System.out.println("Attempted Questions --> " +val);
	 driver.findElement(By.id("countbtn")).click();
	 driver.findElement(By.id("loginmobile")).sendKeys("9067250618");
	 driver.findElement(By.id("loginbtn")).click();
	 int num=Integer.parseInt(val);
	 for(int i=0;i<=num+2;i++)

	 {
	 WebElement nextButton = driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
	 JavascriptExecutor js = (JavascriptExecutor)driver;
	 js.executeScript("arguments[0].click()", nextButton);
	 driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");

	 }

	 driver.findElement(By.id("qsubmit")).click();
	 String msg =driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
	 System.out.println(msg);

	 String expectedResult="Your Result";
	 String actualResult=driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
	 //driver.close();
	 Assert.assertEquals(actualResult, expectedResult);


	 }
	 public void CheckExam10QueFunctionality()

	 {
	 WebDriver driver = null;
	 Actions actions = new Actions(driver);
	 driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
	 String val=driver.findElement(By.name("count")).getAttribute("value");
	 System.out.println(" Attempted Questions --> " +val);
	 driver.findElement(By.id("countbtn")).click();
	 driver.findElement(By.id("loginmobile")).sendKeys("9067250618");
	 driver.findElement(By.id("loginbtn")).click();
	 int num=Integer.parseInt(val);
	 for(int i=0;i<=num+1;i++)

	 {
	 WebElement nextButton =
	driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
	 JavascriptExecutor js = (JavascriptExecutor)driver;
	 js.executeScript("arguments[0].click()", nextButton);
	 driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");

	 }


	 driver.findElement(By.xpath("//*[text()='Submit']")).click();
	 String msg =driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
	 System.out.println(msg);

	 String expectedResult="Your Result";
	 String actualResult=driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
	 // driver.close();
	 Assert.assertEquals(actualResult, expectedResult);

	}
	 public void checkDownloadCertificateFunctionality()

	 {
	  WebDriver driver = null;
	  Actions actions = new Actions(driver);
	  driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[1]/a")).click();

	  driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[1]/div[2]/h1/a")).click();
	  driver.findElement(By.xpath("//*[@id='Placement-Policy']/div/div/a/div")).click();
	  String val=driver.findElement(By.name("count")).getAttribute("value");
	  System.out.println(val);
	  driver.findElement(By.id("countbtn")).click();
	  driver.findElement(By.id("loginmobile")).sendKeys("9067250618");
	  driver.findElement(By.id("loginbtn")).click();
	  driver.findElement(By.xpath("//*[@id='choices']/div[1]/label/div")).click();
	  int num=Integer.parseInt(val);
	  for(int i=0;i<=num+1;i++)
	  {
	  WebElement nextButton = driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
	  JavascriptExecutor js = (JavascriptExecutor)driver;
	  js.executeScript("arguments[0].click()", nextButton);
	  driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");

	  }

	  driver.findElement(By.id("qsubmit")).click();
	  driver.findElement(By.xpath("//*[text()='Download Your Certificate']")).click();
	  String actualResult = driver.findElement(By.xpath("//h3[text()='Your Result']")).getText();
	  String expectedResult= "Your Result";
	  //driver.close();
	  Assert.assertEquals(actualResult, expectedResult);

	  }
	 public void CheckHomeFunctionality()

	 {
	 WebDriver driver = null;
	 Actions actions = new Actions(driver);
	 driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
	 driver.findElement(By.id("countbtn")).click();
	 driver.findElement(By.id("loginmobile")).sendKeys("9067250618");
	 driver.findElement(By.id("loginbtn")).click();
	 driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
	 driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[1]/a")).click(); // click on Home
	 String TextDisplay =driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[1]/div[2]/h1")).getText();
	 System.out.println(TextDisplay); //Take a Online TestText Display
	 String ActHomePage =driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[1]/div[2]/p")).getText();
	 String ExpHomePage = "Check your experties & improve your skills";
	 //driver.close();
	 Assert.assertEquals(ActHomePage, ExpHomePage);

	 } 
	 public void CheckTotalAttemptedExamFunctionality()
	 {
	 WebDriver driver = null;
	 Actions actions = new Actions(driver);
	 driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
	 String val=driver.findElement(By.name("count")).getAttribute("value");
	 System.out.println("Currently Attempted Questions --> " +val);
	 driver.findElement(By.id("countbtn")).click();
	 driver.findElement(By.id("loginmobile")).sendKeys("9067250618");
	 driver.findElement(By.id("loginbtn")).click();
	 int num=Integer.parseInt(val);
	 for(int i=0;i<=num+2;i++)

	 {
	 WebElement nextButton =driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
	 JavascriptExecutor js = (JavascriptExecutor)driver;
	 js.executeScript("arguments[0].click()", nextButton);
	 driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");
	 }
	 driver.findElement(By.id("qsubmit")).click();
	 driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
	 String TotalAttemtedQuiz =
	driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[1]/div/div/div/div[1]/div/h4")).getText();
	 System.out.println(TotalAttemtedQuiz);

	driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[1]/div/div/div/div[1]/div/a")).click(); //click on view details
	 WebElement CheckTotalAttemptsAndScrollDown=driver.findElement(By.xpath("/html/body/footer/div[2]/p"));
	 JavascriptExecutor js = (JavascriptExecutor)driver;
	 js.executeScript("arguments[0].scrollIntoView();",CheckTotalAttemptsAndScrollDown);
	 WebElement up = driver.findElement(By.xpath("/html/body/div/div/div[2]/div/div[1]/h4"));
	 actions.sendKeys(up, Keys.ARROW_UP).perform();
	 String ActualMsg = driver.findElement(By.xpath("//h4[text()='Test Attempted']")).getText();
	 String ExpectedMsg ="Test Attempted" ;
	 //driver.close();
	 Assert.assertEquals(ActualMsg, ExpectedMsg);


	 }
	 public void CheckTotalFailedExamFunctionality()

	 {
	 WebDriver driver = null;
	 Actions actions = new Actions(driver);
	 driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
	 driver.findElement(By.id("countbtn")).click();
	 driver.findElement(By.id("loginmobile")).sendKeys("6666444411");
	 driver.findElement(By.id("loginbtn")).click();
	 driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
	 String TotalFailedtoAttemtedQuiz =
	 driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[3]/div/div/div/div[1]/div/h4")).getText();
	 System.out.println(TotalFailedtoAttemtedQuiz);
	 driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[3]/div/div/div/div[1]/div/a")).click(); //click on failed to attempt
	 WebElement CheckTotalFailedAttemptsAndScrollDown =
	 driver.findElement(By.xpath("//*[text()='jbktest Copyright @ 2020. All rights reserved.']"));
	 JavascriptExecutor js = (JavascriptExecutor)driver;
	 js.executeScript("arguments[0].scrollIntoView();",CheckTotalFailedAttemptsAndScrollDown);
	 WebElement up = driver.findElement(By.xpath("/html/body/div/div/div[2]/div/div[1]/h4"));
	 actions.sendKeys(up, Keys.ARROW_UP).perform();
	 String ActualResult = driver.findElement(By.xpath("//*[text()='Failed Attempt']")).getText();
	 String ExpectedResult ="Failed Attempt" ;
	 //driver.close();
	 Assert.assertEquals(ActualResult, ExpectedResult);

	 }
	 public void CheckGoodScoreFunctionality()

	 {
	 WebDriver driver = null;
	 Actions actions = new Actions(driver);
	 driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();

	 driver.findElement(By.id("countbtn")).click();
	 driver.findElement(By.id("loginmobile")).sendKeys("9067250618");
	 driver.findElement(By.id("loginbtn")).click();

	 driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();// Click on My account
     String YourGoodScore = driver.findElement(By.xpath("//h4[text()='25']")).getText();
	 System.out.println(" Your Good Score is --> "+YourGoodScore);
	 driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[2]/div/div/div/div[1]/div/a")).click();
	 String ActTextDisplay = driver.findElement(By.xpath("//h4[text()='Good Score']")).getText();
	 String ExpTextDisplay = "Good Score";
	 //driver.close();
	 Assert.assertEquals(ActTextDisplay, ExpTextDisplay);


	 }
	 public void ChecLogoutFunctionality()

	 {
	 WebDriver driver = null;
		Actions actions = new Actions(driver);
	 driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
	 driver.findElement(By.id("countbtn")).click();
	 driver.findElement(By.id("loginmobile")).sendKeys("9067250618");
	 driver.findElement(By.id("loginbtn")).click();


	 driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
	 driver.findElement(By.xpath("//a[text()='Logout']")).click();

	 String ActHomePage =
	driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[1]/div[2]/p")).getText();
	 String ExpHomePage = "welcome pooja pawar";
	 //driver.close();
	 Assert.assertEquals(ActHomePage, ExpHomePage);

	 }

	}